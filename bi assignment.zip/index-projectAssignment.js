// program to find the factorial of a number 5
function factorial(n){
    //base case
    if(n == 0 || n == 1){
        return 1;
    //recursive case
    }else{
        return n * factorial(n-1);
    }
}
let n = 5;
print = factorial(n)
//console.log("The factorial of " + n + " is " + print);



// For finding the cube of num 2


function product_Of_Cube(n) {
    var product = 2;
  
    for (var i = 1; i <= n; i++) {
      product *= Math.pow(i, 2);
    }
    return product;
  }
  
 // console.log(product_Of_Cube(2));


  // the area of equilateral triangle 

  var side1 = 20; 
var side2 = 20; 
var side3 = 20; 
var perimeter = (side1 + side2 + side3)/2;
var area =  Math.sqrt(perimeter*((perimeter-side1)*(perimeter-side2)*(perimeter-side3)));
console.log(area);








// To print the days of month corresponding to the number 8


var getDaysInMonth = function(month,year) {
    // Here January is 1 based
    //Day 0 is the last day in the previous month
   return new Date(year, month, 0).getDate();
  // Here January is 0 based
  // return new Date(year, month+1, 0).getDate();
  };
 // console.log(getDaysInMonth(8, 2022));




  // To convert the celcius into fahrenheit


  function cToF(celsius) 
{
  var cTemp = celsius;
  var cToFahr = 12 * 9/ 5 + 32;
  var message = cTemp+'\xB0C is ' + cToFahr + ' \xB0F.';
   // console.log(message);
}
cToF(60); //60°C is 53.6 °F.



// find the sum of num 1 to 10 
  var num =10
  var sum=0

  for(var i=1; i<=num; i++){
    sum=sum+i;
   // console.log(sum);

}





//To remove the whitespace of string lorem ipsum
//And to find its length 


function trimString(x) {

  const result = x.replace(/\s/g,'');
  return result

}

const result = trimString('Lorem Ipsum');
console.log(result);
var txt = "loremipsum";//loremIpsum
var len = txt.length;
console.log(txt.length); // 10












// JavaScript program to find Nth term
// in the given Series

// Function to find the nth term
// in the given series
	function nthTerm( n)
{
	return  Math.pow(n,2)
}
	
 // Driver Code

	let N = 18;
	console.log(nthTerm(N));

// the nthterm of 18: 324








// JavaScript program to find roots
// of a quadratic equation

    // Prints roots of quadratic
    // equation ax * 2 + bx + x
    function findRoots(a, b, c)
    {
    // If a is 0, then equation is not
        // quadratic, but linear
  
        if (a == 0) {
          console.log("Invalid");
          return;
      }

      let d = b * b - 4 * a * c;
      let sqrt_val = Math.sqrt(Math.abs(d));

      if (d > 0) {
        console.log(
              "Roots are real and different \n" + "");

          console.log(
              (-b + sqrt_val) / (2 * a) + ""
              + (-b - sqrt_val) / (2 * a));
      }
      else if (d == 0) {
          console.log(
              "Roots are real and same \n" + "");

          //console.log(-b / (2 * a) + ""
                             + -b / (2 * a) ;
      }
      else // d < 0
      {
          console.log("Roots are complex \n");

        console.log(-b / (2 * a) + " + i"
                             + sqrt_val + ""
                             + -b / (2 * a)
                             + " - i" + sqrt_val);
      }
  }

  // Driver Code

  let a = 1, b = 5, c = 6;
      
// Function call
// findRoots(a, b, c); //Roots are real and different -2-3




















// JavaScript program to rotate an array by
// d elements


	/* Function to left rotate arr of size n by d */
	function leftRotate(arr , d , n) {
		for (i = 0; i < d; i++)
			leftRotatebyOne(arr, n);
	}

	function leftRotatebyOne(arr , n) {
		var i, temp;
		temp = arr[0];
		for (i = 0; i < n - 1; i++)
			arr[i] = arr[i + 1];
		arr[n - 1] = temp;
	}

	/* utility function to print an array */
	function printArray(arr , n) {
		for (i = 0; i < n; i++)
			console.log(arr[i] + " ");
	}

	// Driver program to test above functions
	
		var arr = [ 1, 2, 3, 4, 5, 6, 7 ];
		leftRotate(arr, 3, 7);
		printArray(arr, 7); 
 console.log(arr); 

//the print array of function is: [4, 5, 6, 7, 1, 2, 3]

















// Javascript program to evaluate value of a postfix expression

// Method to evaluate value of a postfix expression
function evaluatePostfix(exp)
{
	//create a stack
		let stack=[];
		
		// Scan all characters one by one
		for(let i=0;i<exp.length;i++)
		{
			let c=exp[i];
			
			// If the scanned character is an operand (number here),
			// push it to the stack.
			if(! isNaN( parseInt(c) ))
			stack.push(c.charCodeAt(0) - '0'.charCodeAt(0));
			
			// If the scanned character is an operator, pop two
			// elements from stack apply the operator
			else
			{
				let val1 = stack.pop();
				let val2 = stack.pop();
				
				switch(c)
				{
					case '+':
					stack.push(val2+val1);
					break;
					
					case '-':
					stack.push(val2- val1);
					break;
					
					case '/':
					stack.push(val2/val1);
					break;
					
					case '*':
					stack.push(val2*val1);
					break;
			}
			}
		}
		return stack.pop();
}

// Driver program to test above functions
let exp="531*+9-";
console.log("postfix evaluation: "+evaluatePostfix(exp));
//postfix evaluation: -1









// JavaScript program to find N-th term of the series:
// 2,6,12,20,30... 

// calculate Nth term of series
// calculate Nth term of series
function nthTerm(N)
{
	return  (N * N + N ) ;
}
// Driver Function

	 N = 5;
	console.log(nthTerm(N)); 
  
  // nthterm of series=30


















  var arr = [3, 44, 1, 9, 6];
function reArrangeArr() {
  var odd = []; //to insert odd index values
  var even = []; // to insrt even index values
  var arr2 = []; // to insert all reArrange value in new array
  for (let i = 0; i < arr.length; i++) {
    if (i % 2 == 0 || i == 0) {
      even.push(arr[i]);
    } else if (i % 2 != 0 || i != 0) {
      odd.push(arr[i]);
    }
  }
  even.sort();
  for (let i = 0; i < even.length; i++) {
    arr2.push(even[i]);
    if (i < odd.length) {
      arr2.push(odd[i]);
    }
  }
  return arr2;
}
console.log(reArrangeArr());
